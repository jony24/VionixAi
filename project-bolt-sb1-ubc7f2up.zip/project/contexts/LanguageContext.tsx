import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'en' | 'bn' | 'hi';

interface Translations {
  [key: string]: {
    [key in Language]: string;
  };
}

const translations: Translations = {
  // Navigation
  home: { en: 'Home', bn: 'হোম', hi: 'होम' },
  templates: { en: 'Templates', bn: 'টেমপ্লেট', hi: 'टेम्प्लेट' },
  profile: { en: 'Profile', bn: 'প্রোফাইল', hi: 'प्रोफ़ाइल' },
  plans: { en: 'Plans', bn: 'প্ল্যান', hi: 'योजनाएं' },
  
  // Home Screen
  welcome: { en: 'Welcome to VionixAI', bn: 'VionixAI তে স্বাগতম', hi: 'VionixAI में आपका स्वागत है' },
  subtitle: { en: 'Create amazing videos with AI', bn: 'AI দিয়ে অসাধারণ ভিডিও তৈরি করুন', hi: 'AI के साथ अद्भुत वीडियो बनाएं' },
  createVideo: { en: 'Create Video', bn: 'ভিডিও তৈরি করুন', hi: 'वीडियो बनाएं' },
  quickStats: { en: 'Quick Stats', bn: 'দ্রুত পরিসংখ্যান', hi: 'त्वरित आंकड़े' },
  videosCreated: { en: 'Videos Created', bn: 'ভিডিও তৈরি', hi: 'वीडियो बनाए गए' },
  templatesUsed: { en: 'Templates Used', bn: 'টেমপ্লেট ব্যবহৃত', hi: 'टेम्प्लेट इस्तेमाल किए' },
  
  // Templates
  popularTemplates: { en: 'Popular Templates', bn: 'জনপ্রিয় টেমপ্লেট', hi: 'लोकप्रिय टेम्प्लेट' },
  business: { en: 'Business', bn: 'ব্যবসা', hi: 'व्यापार' },
  social: { en: 'Social Media', bn: 'সোশ্যাল মিডিয়া', hi: 'सोशल मीडिया' },
  educational: { en: 'Educational', bn: 'শিক্ষামূলক', hi: 'शैक्षिक' },
  entertainment: { en: 'Entertainment', bn: 'বিনোদন', hi: 'मनोरंजन' },
  
  // Authentication
  signIn: { en: 'Sign In', bn: 'সাইন ইন', hi: 'साइन इन' },
  signUp: { en: 'Sign Up', bn: 'সাইন আপ', hi: 'साइन अप' },
  email: { en: 'Email', bn: 'ইমেইল', hi: 'ईमेल' },
  password: { en: 'Password', bn: 'পাসওয়ার্ড', hi: 'पासवर्ड' },
  name: { en: 'Full Name', bn: 'পূর্ণ নাম', hi: 'पूरा नाम' },
  continueWithGoogle: { en: 'Continue with Google', bn: 'Google দিয়ে চালিয়ে যান', hi: 'Google के साथ जारी रखें' },
  
  // Subscription
  choosePlan: { en: 'Choose Your Plan', bn: 'আপনার প্ল্যান বেছে নিন', hi: 'अपनी योजना चुनें' },
  free: { en: 'Free', bn: 'ফ্রি', hi: 'मुफ्त' },
  pro: { en: 'Pro', bn: 'প্রো', hi: 'प्रो' },
  premium: { en: 'Premium', bn: 'প্রিমিয়াম', hi: 'प्रीमियम' },
  month: { en: '/month', bn: '/মাস', hi: '/महीना' },
  upgrade: { en: 'Upgrade', bn: 'আপগ্রেড', hi: 'अपग्रेड' },
  current: { en: 'Current Plan', bn: 'বর্তমান প্ল্যান', hi: 'वर्तमान योजना' },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[key]?.[language] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}