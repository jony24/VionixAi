import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Image,
} from 'react-native';
import { useLanguage } from '@/contexts/LanguageContext';
import { 
  Search, 
  Filter,
  Play,
  Heart,
  Download,
  Star
} from 'lucide-react-native';

const { width } = Dimensions.get('window');

interface Template {
  id: string;
  title: string;
  category: string;
  thumbnail: string;
  duration: string;
  rating: number;
  downloads: string;
  isPro: boolean;
}

const mockTemplates: Template[] = [
  {
    id: '1',
    title: 'Modern Business Promo',
    category: 'business',
    thumbnail: 'https://images.pexels.com/photos/3184287/pexels-photo-3184287.jpeg?auto=compress&cs=tinysrgb&w=400',
    duration: '0:30',
    rating: 4.8,
    downloads: '12K',
    isPro: false,
  },
  {
    id: '2',
    title: 'Instagram Story Template',
    category: 'social',
    thumbnail: 'https://images.pexels.com/photos/267350/pexels-photo-267350.jpeg?auto=compress&cs=tinysrgb&w=400',
    duration: '0:15',
    rating: 4.9,
    downloads: '25K',
    isPro: true,
  },
  {
    id: '3',
    title: 'Educational Explainer',
    category: 'educational',
    thumbnail: 'https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?auto=compress&cs=tinysrgb&w=400',
    duration: '1:00',
    rating: 4.7,
    downloads: '8K',
    isPro: false,
  },
  {
    id: '4',
    title: 'Product Showcase',
    category: 'business',
    thumbnail: 'https://images.pexels.com/photos/335257/pexels-photo-335257.jpeg?auto=compress&cs=tinysrgb&w=400',
    duration: '0:45',
    rating: 4.6,
    downloads: '15K',
    isPro: true,
  },
  {
    id: '5',
    title: 'Gaming Montage',
    category: 'entertainment',
    thumbnail: 'https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=400',
    duration: '1:30',
    rating: 4.8,
    downloads: '30K',
    isPro: false,
  },
  {
    id: '6',
    title: 'Food Recipe Video',
    category: 'entertainment',
    thumbnail: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=400',
    duration: '2:00',
    rating: 4.9,
    downloads: '20K',
    isPro: true,
  },
];

export default function TemplatesScreen() {
  const { t } = useLanguage();
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { id: 'all', label: 'All', count: mockTemplates.length },
    { id: 'business', label: t('business'), count: mockTemplates.filter(t => t.category === 'business').length },
    { id: 'social', label: t('social'), count: mockTemplates.filter(t => t.category === 'social').length },
    { id: 'educational', label: t('educational'), count: mockTemplates.filter(t => t.category === 'educational').length },
    { id: 'entertainment', label: t('entertainment'), count: mockTemplates.filter(t => t.category === 'entertainment').length },
  ];

  const filteredTemplates = selectedCategory === 'all' 
    ? mockTemplates 
    : mockTemplates.filter(template => template.category === selectedCategory);

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>{t('templates')}</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.iconButton}>
            <Search color="#666" size={24} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconButton}>
            <Filter color="#666" size={24} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Categories */}
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.categoriesContainer}
        contentContainerStyle={styles.categoriesContent}
      >
        {categories.map((category) => (
          <TouchableOpacity
            key={category.id}
            style={[
              styles.categoryButton,
              selectedCategory === category.id && styles.activeCategoryButton
            ]}
            onPress={() => setSelectedCategory(category.id)}
          >
            <Text
              style={[
                styles.categoryText,
                selectedCategory === category.id && styles.activeCategoryText
              ]}
            >
              {category.label} ({category.count})
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Templates Grid */}
      <ScrollView 
        style={styles.templatesContainer}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.templatesGrid}>
          {filteredTemplates.map((template) => (
            <TouchableOpacity key={template.id} style={styles.templateCard}>
              <View style={styles.templateImageContainer}>
                <Image source={{ uri: template.thumbnail }} style={styles.templateImage} />
                <View style={styles.templateOverlay}>
                  <TouchableOpacity style={styles.playButton}>
                    <Play color="#fff" size={20} fill="#fff" />
                  </TouchableOpacity>
                  <View style={styles.templateBadges}>
                    {template.isPro && (
                      <View style={styles.proBadge}>
                        <Star color="#FFD700" size={12} fill="#FFD700" />
                        <Text style={styles.proText}>PRO</Text>
                      </View>
                    )}
                    <Text style={styles.durationBadge}>{template.duration}</Text>
                  </View>
                </View>
              </View>
              <View style={styles.templateInfo}>
                <Text style={styles.templateTitle} numberOfLines={2}>
                  {template.title}
                </Text>
                <View style={styles.templateStats}>
                  <View style={styles.statItem}>
                    <Star color="#FFD700" size={12} fill="#FFD700" />
                    <Text style={styles.statText}>{template.rating}</Text>
                  </View>
                  <View style={styles.statItem}>
                    <Download color="#666" size={12} />
                    <Text style={styles.statText}>{template.downloads}</Text>
                  </View>
                </View>
              </View>
              <TouchableOpacity style={styles.favoriteButton}>
                <Heart color="#ccc" size={16} />
              </TouchableOpacity>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 24,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#1a1a1a',
  },
  headerActions: {
    flexDirection: 'row',
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f0f0f0',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 12,
  },
  categoriesContainer: {
    backgroundColor: '#fff',
  },
  categoriesContent: {
    paddingHorizontal: 24,
    paddingBottom: 20,
  },
  categoryButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: '#f0f0f0',
    marginRight: 12,
  },
  activeCategoryButton: {
    backgroundColor: '#5B73FF',
  },
  categoryText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#666',
  },
  activeCategoryText: {
    color: '#fff',
  },
  templatesContainer: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 20,
  },
  templatesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  templateCard: {
    width: (width - 64) / 2,
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  templateImageContainer: {
    position: 'relative',
    width: '100%',
    height: 120,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    overflow: 'hidden',
  },
  templateImage: {
    width: '100%',
    height: '100%',
  },
  templateOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  playButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  templateBadges: {
    position: 'absolute',
    top: 8,
    right: 8,
    alignItems: 'flex-end',
  },
  proBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
    marginBottom: 4,
  },
  proText: {
    fontSize: 10,
    fontFamily: 'Inter-Bold',
    color: '#FFD700',
    marginLeft: 2,
  },
  durationBadge: {
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    color: '#fff',
    fontSize: 10,
    fontFamily: 'Inter-Medium',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
  },
  templateInfo: {
    padding: 12,
  },
  templateTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1a1a1a',
    marginBottom: 8,
  },
  templateStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#666',
    marginLeft: 4,
  },
  favoriteButton: {
    position: 'absolute',
    top: 8,
    left: 8,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
});