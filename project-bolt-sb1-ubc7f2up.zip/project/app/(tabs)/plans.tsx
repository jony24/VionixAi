import React from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { 
  Check,
  Star,
  Crown,
  Zap,
  Sparkles,
  Video,
  Download,
  Palette,
  Shield,
  Headphones
} from 'lucide-react-native';

interface PlanFeature {
  text: string;
  included: boolean;
}

interface Plan {
  id: string;
  name: string;
  price: string;
  period: string;
  description: string;
  popular?: boolean;
  gradient: string[];
  icon: React.ComponentType<any>;
  features: PlanFeature[];
}

export default function PlansScreen() {
  const { user } = useAuth();
  const { t } = useLanguage();

  const plans: Plan[] = [
    {
      id: 'free',
      name: t('free'),
      price: '৳0',
      period: t('month'),
      description: 'Perfect for getting started',
      gradient: ['#E8F4FD', '#D1E7DD'],
      icon: Sparkles,
      features: [
        { text: '5 video templates', included: true },
        { text: 'Basic editing tools', included: true },
        { text: '720p video export', included: true },
        { text: 'Watermark on videos', included: true },
        { text: 'Community support', included: true },
        { text: 'HD video export', included: false },
        { text: 'Premium templates', included: false },
        { text: 'AI voice generation', included: false },
        { text: 'Priority support', included: false },
        { text: 'Commercial license', included: false },
      ]
    },
    {
      id: 'pro',
      name: t('pro'),
      price: '৳৪৯৯',
      period: t('month'),
      description: 'Best for content creators',
      popular: true,
      gradient: ['#667eea', '#764ba2'],
      icon: Crown,
      features: [
        { text: '50+ video templates', included: true },
        { text: 'Advanced editing tools', included: true },
        { text: 'HD video export (1080p)', included: true },
        { text: 'No watermark', included: true },
        { text: 'Premium templates', included: true },
        { text: 'AI voice generation', included: true },
        { text: 'Priority support', included: true },
        { text: 'Stock media library', included: true },
        { text: '4K video export', included: false },
        { text: 'Commercial license', included: false },
      ]
    },
    {
      id: 'premium',
      name: t('premium'),
      price: '৳৯৯৯',
      period: t('month'),
      description: 'For professional creators',
      gradient: ['#f093fb', '#f5576c'],
      icon: Zap,
      features: [
        { text: 'Unlimited templates', included: true },
        { text: 'Professional editing suite', included: true },
        { text: '4K video export', included: true },
        { text: 'No watermark', included: true },
        { text: 'All premium templates', included: true },
        { text: 'AI voice generation', included: true },
        { text: 'Priority support', included: true },
        { text: 'Commercial license', included: true },
        { text: 'White-label solution', included: true },
        { text: 'API access', included: true },
      ]
    }
  ];

  const handleUpgrade = (planId: string) => {
    if (planId === 'free') {
      Alert.alert('Current Plan', 'You are already on the free plan!');
      return;
    }

    Alert.alert(
      'Upgrade Plan',
      `This feature will be available soon. You selected the ${planId.toUpperCase()} plan.`,
      [
        { text: 'Notify Me', onPress: () => console.log('User wants notification') },
        { text: 'OK', style: 'cancel' }
      ]
    );
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <LinearGradient
        colors={['#667eea', '#764ba2']}
        style={styles.header}
      >
        <Text style={styles.title}>{t('choosePlan')}</Text>
        <Text style={styles.subtitle}>
          Unlock the full potential of VionixAI
        </Text>
      </LinearGradient>

      {/* Current Plan Info */}
      <View style={styles.currentPlanSection}>
        <View style={styles.currentPlanCard}>
          <View style={styles.currentPlanHeader}>
            <Star color="#FFD700" size={20} fill="#FFD700" />
            <Text style={styles.currentPlanTitle}>{t('current')}</Text>
          </View>
          <Text style={styles.currentPlanName}>
            {user?.subscription?.toUpperCase() || 'FREE'} PLAN
          </Text>
          <Text style={styles.currentPlanDescription}>
            {user?.subscription === 'free' || !user?.subscription
              ? 'You are currently on the free plan with basic features'
              : `You have access to ${user.subscription} features and benefits`
            }
          </Text>
        </View>
      </View>

      {/* Plans */}
      <View style={styles.plansSection}>
        {plans.map((plan) => (
          <View key={plan.id} style={styles.planCard}>
            {plan.popular && (
              <View style={styles.popularBadge}>
                <Text style={styles.popularText}>MOST POPULAR</Text>
              </View>
            )}
            
            <LinearGradient
              colors={plan.gradient}
              style={styles.planHeader}
            >
              <plan.icon color="#fff" size={32} />
              <Text style={styles.planName}>{plan.name}</Text>
              <View style={styles.priceContainer}>
                <Text style={styles.price}>{plan.price}</Text>
                <Text style={styles.period}>{plan.period}</Text>
              </View>
              <Text style={styles.planDescription}>{plan.description}</Text>
            </LinearGradient>

            <View style={styles.planBody}>
              <View style={styles.featuresContainer}>
                {plan.features.map((feature, index) => (
                  <View key={index} style={styles.featureItem}>
                    <View style={[
                      styles.featureIcon,
                      { backgroundColor: feature.included ? '#E8F5E8' : '#F5F5F5' }
                    ]}>
                      <Check 
                        color={feature.included ? '#4CAF50' : '#CCC'} 
                        size={16} 
                      />
                    </View>
                    <Text style={[
                      styles.featureText,
                      { color: feature.included ? '#1a1a1a' : '#999' }
                    ]}>
                      {feature.text}
                    </Text>
                  </View>
                ))}
              </View>

              <TouchableOpacity
                style={[
                  styles.upgradeButton,
                  plan.id === (user?.subscription || 'free') && styles.currentButton
                ]}
                onPress={() => handleUpgrade(plan.id)}
                disabled={plan.id === (user?.subscription || 'free')}
              >
                <Text style={[
                  styles.upgradeButtonText,
                  plan.id === (user?.subscription || 'free') && styles.currentButtonText
                ]}>
                  {plan.id === (user?.subscription || 'free') 
                    ? t('current') 
                    : plan.id === 'free' 
                      ? 'Get Started' 
                      : t('upgrade')
                  }
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </View>

      {/* Features Comparison */}
      <View style={styles.comparisonSection}>
        <Text style={styles.comparisonTitle}>Why Upgrade?</Text>
        <View style={styles.comparisonGrid}>
          {[
            { icon: Video, title: 'HD Quality', desc: 'Export in stunning HD' },
            { icon: Palette, title: 'Premium Templates', desc: '100+ professional designs' },
            { icon: Download, title: 'No Watermark', desc: 'Clean, professional videos' },
            { icon: Shield, title: 'Commercial Use', desc: 'Use for business projects' },
            { icon: Sparkles, title: 'AI Features', desc: 'Voice generation & more' },
            { icon: Headphones, title: 'Priority Support', desc: '24/7 dedicated help' },
          ].map((feature, index) => (
            <View key={index} style={styles.comparisonCard}>
              <View style={styles.comparisonIcon}>
                <feature.icon color="#5B73FF" size={24} />
              </View>
              <Text style={styles.comparisonCardTitle}>{feature.title}</Text>
              <Text style={styles.comparisonCardDesc}>{feature.desc}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* FAQ Section */}
      <View style={styles.faqSection}>
        <Text style={styles.faqTitle}>Frequently Asked Questions</Text>
        <View style={styles.faqCard}>
          <Text style={styles.faqQuestion}>Can I cancel anytime?</Text>
          <Text style={styles.faqAnswer}>
            Yes, you can cancel your subscription at any time. Your access will continue until the end of your billing period.
          </Text>
        </View>
        <View style={styles.faqCard}>
          <Text style={styles.faqQuestion}>Do you offer refunds?</Text>
          <Text style={styles.faqAnswer}>
            We offer a 30-day money-back guarantee if you're not satisfied with our service.
          </Text>
        </View>
        <View style={styles.faqCard}>
          <Text style={styles.faqQuestion}>Can I change plans later?</Text>
          <Text style={styles.faqAnswer}>
            Absolutely! You can upgrade or downgrade your plan at any time from your profile settings.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 32,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#fff',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#fff',
    opacity: 0.9,
    textAlign: 'center',
  },
  currentPlanSection: {
    paddingHorizontal: 24,
    marginTop: -16,
    marginBottom: 32,
  },
  currentPlanCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 6,
  },
  currentPlanHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  currentPlanTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#FFD700',
    marginLeft: 8,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  currentPlanName: {
    fontSize: 20,
    fontFamily: 'Poppins-Bold',
    color: '#1a1a1a',
    marginBottom: 4,
  },
  currentPlanDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#666',
    lineHeight: 20,
  },
  plansSection: {
    paddingHorizontal: 24,
  },
  planCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 6,
    position: 'relative',
  },
  popularBadge: {
    position: 'absolute',
    top: -8,
    left: 24,
    right: 24,
    backgroundColor: '#FF6B35',
    borderRadius: 20,
    paddingVertical: 8,
    alignItems: 'center',
    zIndex: 1,
  },
  popularText: {
    fontSize: 12,
    fontFamily: 'Inter-Bold',
    color: '#fff',
    letterSpacing: 1,
  },
  planHeader: {
    padding: 24,
    paddingTop: 32,
    alignItems: 'center',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  planName: {
    fontSize: 24,
    fontFamily: 'Poppins-Bold',
    color: '#fff',
    marginTop: 12,
    marginBottom: 8,
    textTransform: 'uppercase',
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginBottom: 8,
  },
  price: {
    fontSize: 36,
    fontFamily: 'Poppins-Bold',
    color: '#fff',
  },
  period: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#fff',
    opacity: 0.9,
    marginLeft: 4,
  },
  planDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#fff',
    opacity: 0.9,
    textAlign: 'center',
  },
  planBody: {
    padding: 24,
  },
  featuresContainer: {
    marginBottom: 24,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  featureIcon: {
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  featureText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    flex: 1,
  },
  upgradeButton: {
    backgroundColor: '#5B73FF',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
  },
  currentButton: {
    backgroundColor: '#E8F4FD',
    borderWidth: 2,
    borderColor: '#5B73FF',
  },
  upgradeButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#fff',
  },
  currentButtonText: {
    color: '#5B73FF',
  },
  comparisonSection: {
    paddingHorizontal: 24,
    marginBottom: 32,
  },
  comparisonTitle: {
    fontSize: 22,
    fontFamily: 'Poppins-SemiBold',
    color: '#1a1a1a',
    marginBottom: 20,
    textAlign: 'center',
  },
  comparisonGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  comparisonCard: {
    width: '48%',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  comparisonIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#5B73FF20',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  comparisonCardTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1a1a1a',
    marginBottom: 4,
    textAlign: 'center',
  },
  comparisonCardDesc: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#666',
    textAlign: 'center',
    lineHeight: 16,
  },
  faqSection: {
    paddingHorizontal: 24,
    marginBottom: 40,
  },
  faqTitle: {
    fontSize: 22,
    fontFamily: 'Poppins-SemiBold',
    color: '#1a1a1a',
    marginBottom: 20,
    textAlign: 'center',
  },
  faqCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  faqQuestion: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1a1a1a',
    marginBottom: 8,
  },
  faqAnswer: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#666',
    lineHeight: 20,
  },
});